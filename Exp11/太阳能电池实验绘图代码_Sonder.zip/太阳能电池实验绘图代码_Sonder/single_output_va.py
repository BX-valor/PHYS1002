import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl

# 中文字体适配
mpl.rcParams["font.sans-serif"] = [
    "PingFang SC",
    "Hiragino Sans GB",
    "Heiti SC",
    "Songti SC",
    "SimHei",
    "Microsoft YaHei",
    "Noto Sans CJK SC",
    "Arial Unicode MS",
]
mpl.rcParams["axes.unicode_minus"] = False

# 请将以下两组数组替换为你的实验数据（各13组）
voltage_v = [
    0.0, 0.2, 0.4, 0.6, 0.8, 1.0, 1.2,
    1.4, 1.6, 1.8, 2.0, 2.2, 2.27,
]

current_ma = [
    11.7, 11.7, 11.7, 11.7, 11.7, 11.6, 11.6,
    11.3, 10.8, 9.7, 7.4, 2.8, 0.023,
]


def plot_output_iv(v, i):
    fig = plt.figure(figsize=(7.2, 5.0))
    plt.plot(
        v,
        i,
        marker="o",
        linewidth=1.8,
        markersize=5,
        color="#9467bd",
    )
    plt.title("单晶硅太阳能电池的输出伏安特性曲线")
    plt.xlabel("电压/V")
    plt.ylabel("电流/mA")
    plt.grid(True, linestyle="--", alpha=0.35)
    plt.tight_layout()

    # 保存图片并展示
    plt.savefig("单晶硅输出伏安特性曲线.png", dpi=150)
    plt.show()


if __name__ == "__main__":
    assert len(voltage_v) == 13 and len(current_ma) == 13, "电压/电流需各 13 组"
    v = np.array(voltage_v, dtype=float)
    i = np.array(current_ma, dtype=float)
    plot_output_iv(v, i)