import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl

# 中文字体适配
mpl.rcParams["font.sans-serif"] = [
    "PingFang SC",
    "Hiragino Sans GB",
    "Heiti SC",
    "Songti SC",
    "SimHei",
    "Microsoft YaHei",
    "Noto Sans CJK SC",
    "Arial Unicode MS",
]
mpl.rcParams["axes.unicode_minus"] = False

# 请将以下两组数组替换为你的实验数据
intensity_w_m2 = [
    70.6, 84.7, 104.4, 134.5, 180.3, 259, 412, 743,
]

isc_ma = [
    8.0, 9.5, 11.6, 14.8, 19.7, 28.1, 43.7, 78.9,
]


def plot_isc(intensity, isc):
    fig = plt.figure(figsize=(7.2, 5.0))
    plt.plot(
        intensity,
        isc,
        marker="o",
        linewidth=1.8,
        markersize=5,
        color="#2ca02c",
    )
    plt.title("单晶硅太阳能电池的短路电流随光照强度变化曲线")
    plt.xlabel("光照强度/W/m^2")
    plt.ylabel("短路电流/mA")
    plt.grid(True, linestyle="--", alpha=0.35)
    plt.tight_layout()

    # 保存图片并展示
    plt.savefig("单晶硅短路电流随光照强度变化曲线.png", dpi=150)
    plt.show()


if __name__ == "__main__":
    assert len(intensity_w_m2) == 8 and len(isc_ma) == 8, "光照强度/短路电流需各 8 组"
    intensity = np.array(intensity_w_m2, dtype=float)
    isc = np.array(isc_ma, dtype=float)
    plot_isc(intensity, isc)