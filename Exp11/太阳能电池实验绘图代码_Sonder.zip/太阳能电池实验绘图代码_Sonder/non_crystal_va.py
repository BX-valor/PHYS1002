import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl

# 中文字体适配
mpl.rcParams["font.sans-serif"] = [
    "PingFang SC",
    "Hiragino Sans GB",
    "Heiti SC",
    "Songti SC",
    "SimHei",
    "Microsoft YaHei",
    "Noto Sans CJK SC",
    "Arial Unicode MS",
]
mpl.rcParams["axes.unicode_minus"] = False

# 请将以下两组数组替换为你的实验数据
voltage_v = [
    -7, -6, -5, -4, -3, -2, -1, 0.0, 0.3, 0.6, 0.9, 1.2,
    1.5, 1.8, 2.1, 2.4, 2.7, 3.0,
]

current_ma = [
    -0.096, -0.081, -0.068, -0.054, -0.040, -0.027, -0.013, 0.0,
    0.004, 0.008, 0.012, 0.017, 0.022, 0.04, 0.141, 0.763, 3.7, 11.5,
]


def plot_dark_iv(v, i):
    fig = plt.figure(figsize=(7.2, 5.0))
    plt.plot(
        v,
        i,
        marker="o",
        linewidth=1.8,
        markersize=5,
        color="#ff7f0e",
    )
    plt.title("非晶硅太阳能电池的暗伏安特性曲线")
    plt.xlabel("电压/V")
    plt.ylabel("电流/mA")
    plt.grid(True, linestyle="--", alpha=0.35)
    plt.tight_layout()

    # 保存图片并展示
    plt.savefig("非晶硅暗伏安特性曲线.png", dpi=150)
    plt.show()


if __name__ == "__main__":
    assert len(voltage_v) == 18 and len(current_ma) == 18, "电压/电流需各 18 组"
    v = np.array(voltage_v, dtype=float)
    i = np.array(current_ma, dtype=float)
    plot_dark_iv(v, i)