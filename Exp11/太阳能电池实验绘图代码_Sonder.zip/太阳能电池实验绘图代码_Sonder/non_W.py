import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl

# 中文字体适配
mpl.rcParams["font.sans-serif"] = [
    "PingFang SC",
    "Hiragino Sans GB",
    "Heiti SC",
    "Songti SC",
    "SimHei",
    "Microsoft YaHei",
    "Noto Sans CJK SC",
    "Arial Unicode MS",
]
mpl.rcParams["axes.unicode_minus"] = False

# 从非晶硅输出VA脚本读取电压、电流（mA）数据
try:
    from non_output_va import voltage_v as _voltage_v, current_ma as _current_ma
except Exception as e:
    raise RuntimeError("导入失败：请先在 non_output_va.py 填写13组电压与电流数据") from e


def compute_power_from_vi(voltage_list, current_ma_list):
    v = np.array(voltage_list, dtype=float)
    i_ma = np.array(current_ma_list, dtype=float)
    assert len(v) == 13 and len(i_ma) == 13, "电压/电流需各 13 组"
    power_w = v * (i_ma * 1e-3)
    return v, power_w


def plot_power_voltage(v, p):
    fig = plt.figure(figsize=(7.2, 5.0))
    plt.plot(
        v,
        p,
        marker="o",
        linewidth=1.8,
        markersize=5,
        color="#d62728",
    )
    plt.title("非晶硅太阳能电池的输出电压-功率曲线")
    plt.xlabel("电压/V")
    plt.ylabel("功率/W")
    plt.grid(True, linestyle="--", alpha=0.35)
    plt.tight_layout()

    # 保存图片并展示
    plt.savefig("非晶硅输出电压-功率曲线.png", dpi=150)
    plt.show()


if __name__ == "__main__":
    v, p = compute_power_from_vi(_voltage_v, _current_ma)
    plot_power_voltage(v, p)