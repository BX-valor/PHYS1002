import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl

# 中文字体适配（在 macOS 上优先使用 PingFang SC 等）
mpl.rcParams["font.sans-serif"] = [
    "PingFang SC",
    "Hiragino Sans GB",
    "Heiti SC",
    "Songti SC",
    "SimHei",
    "Microsoft YaHei",
    "Noto Sans CJK SC",
    "Arial Unicode MS",
]
mpl.rcParams["axes.unicode_minus"] = False


voltage_v = [
    -7, -6, -5, -4, -3, -2, -1, 0.0, 0.3, 0.6, 0.9, 1.2,
    1.5, 1.8, 2.1, 2.4, 2.7,
]

current_ma = [
    -0.17, -0.144, -0.118, -0.093, -0.069, -0.045, -0.022, 0.0,
    0.011, 0.031, 0.073, 0.185, 0.492, 1.474, 4.5, 14.0, 42.3,
]


def plot_dark_iv(voltage_v, current_ma):
    fig = plt.figure(figsize=(7.2, 5.0))
    plt.plot(
        voltage_v,
        current_ma,
        marker="o",
        linewidth=1.8,
        markersize=5,
        color="#1f77b4",
    )
    plt.title("单晶硅太阳能电池的暗伏安特性曲线")
    plt.xlabel("电压/V")
    plt.ylabel("电流/mA")
    plt.grid(True, linestyle="--", alpha=0.35)
    plt.tight_layout()

    # 保存图片并展示
    plt.savefig("单晶硅暗伏安特性曲线.png", dpi=150)
    plt.show()


if __name__ == "__main__":
    assert len(voltage_v) == 17 and len(current_ma) == 17, "电压/电流需各 17 组"
    v = np.array(voltage_v, dtype=float)
    i = np.array(current_ma, dtype=float)
    plot_dark_iv(v, i)